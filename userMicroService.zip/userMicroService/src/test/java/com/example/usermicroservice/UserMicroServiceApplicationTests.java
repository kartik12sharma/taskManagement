package com.example.usermicroservice;

import com.example.usermicroservice.security.repositories.clientRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.core.oidc.OidcScopes;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.settings.ClientSettings;
import org.springframework.test.annotation.Commit;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.UUID;

@SpringBootTest
class UserMicroServiceApplicationTests {
    @Autowired
    RegisteredClientRepository clientRepo;
    @Autowired
    BCryptPasswordEncoder encoder;

//    @Autowired
//    RestTemplateBuilder restTemp;


//    public UserMicroServiceApplicationTests(RegisteredClientRepository cR, BCryptPasswordEncoder en){
//        clientRepo = cR;
//        encoder = en;
//    }

//    @Test
//    @Commit
    void addClientToDatabase() {
        RegisteredClient oidcClient = RegisteredClient.withId(UUID.randomUUID().toString())
                .clientId("kartik")
                .clientSecret(encoder.encode("password"))
                .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
                .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
                .authorizationGrantType(AuthorizationGrantType.REFRESH_TOKEN)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .redirectUri("http://tempus.eu-north-1.elasticbeanstalk.com:5000/login/oauth2/code/oidc-client")
                .redirectUri("https://oauth.pstmn.io/v1/callback")
                .postLogoutRedirectUri("http://tempus.eu-north-1.elasticbeanstalk.com:5000/")
                .scope(OidcScopes.OPENID)
                .scope(OidcScopes.PROFILE)
                .clientSettings(ClientSettings.builder().requireAuthorizationConsent(true).build())
                .build();
        clientRepo.save(oidcClient);
    }
//    @Test
//    public void checkSecuredApis(){
//        RestTemplate rest = restTemp.build();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
//        headers.set("sample", "eyJraWQiOiJkNzZiY2VhMi04ODk5LTQzZjItOTU4NC05ZTAxZmY0NDMyODkiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJoZWxsbyIsImF1ZCI6ImthcnRpayIsIm5iZiI6MTcyMjY1NjM2Mywic2NvcGUiOlsicHJvZmlsZSJdLCJyb2xlcyI6WyJUQSJdLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjkwMDAiLCJpZCI6MywiZXhwIjoxNzIyNjU2NjYzLCJpYXQiOjE3MjI2NTYzNjMsImp0aSI6IjRiZjJiYzI1LWI2MzEtNGYyYS1hYWM2LWUzZDlkZjhiMjVmYSJ9.jU-LeKkRbqJUU8-K2GEoLFAz4ugzoIjvKPK2e8vXKIQANGA5kx8VdrCPAjY6WG9xk1NSwk4ZB4jooASPPdTLX99inKvBUUCe6XDIhWNjcdIPs2CjAk2QxQe8faTvffiUKKFK92vFX8HGqMHRjUKhLFJMae0CRebOoGK0niHC9sels2ncrEhEsHrARDLj27GJpBFkguK7tF2b7JSsOuofYysKSFsxuIOiVAgk3Cb04H1KL5Lx7ekq8ZBNgB9YGshGEXLaPG9vqVftoRiDUbmpuajMiBcte_wDnxp13jqupeMib3C5B7G3oScDI0sn_uDmm2zjwGd3DYz6WbjlbCw0nw");
//        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
//        ResponseEntity<Object> response = rest.exchange("http://localhost:8080/products/all", HttpMethod.GET, entity, Object.class );
////        Object obj = response.getBody();
////        System.out.println(obj.toString());
//    }

}
