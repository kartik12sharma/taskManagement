package com.example.usermicroservice.security.repositories;

import com.example.usermicroservice.security.models.client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface clientRepository extends JpaRepository<client, String> {
    Optional<client> findByClientId(String clientId);
}
