package com.example.usermicroservice.services;
import com.example.usermicroservice.exceptions.notFoundException;
import com.example.usermicroservice.models.user;
import org.springframework.http.ResponseEntity;
import java.util.UUID;
import com.example.usermicroservice.DTOs.userDTO;

public interface userService {
    public userDTO getUserByID(Long id) throws notFoundException;
    public userDTO deleteUserByID(Long id) throws notFoundException;
    public userDTO save(userDTO obj);
}
