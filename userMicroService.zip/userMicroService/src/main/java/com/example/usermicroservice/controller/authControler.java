package com.example.usermicroservice.controller;

import com.example.usermicroservice.DTOs.logOutDTO;
import com.example.usermicroservice.DTOs.loginDTO;
import com.example.usermicroservice.DTOs.signUpDTO;
import com.example.usermicroservice.DTOs.userDTO;
import com.example.usermicroservice.exceptions.inValidUserException;
import com.example.usermicroservice.exceptions.notFoundException;
import com.example.usermicroservice.models.user;
import com.example.usermicroservice.services.authService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.InvalidKeyException;

@RestController()
@RequestMapping("/auth")
public class authControler {
    private authService auth;
    @Autowired
    public authControler(authService serv){
        auth = serv;
    }
    @PostMapping("/signup")
    public userDTO signUp(@RequestBody signUpDTO dto){
        return auth.signUp(dto.getEmail(), dto.getPassword(), dto.getUserName());
    }
    @PostMapping("/login")
    public ResponseEntity<userDTO> logIn(@RequestBody loginDTO dto) throws notFoundException, InvalidKeyException {
        ResponseEntity<userDTO> temp = auth.logIn(dto.getEmail(), dto.getPassword());
        return temp;
    }
    @PostMapping("/logout")
    public ResponseEntity<String> logOut(@RequestBody logOutDTO logoutdto){
        return auth.logOut(logoutdto);
    }
    @GetMapping("/validate/{userEmail}")
    public boolean validate(@PathVariable("userEmail") String mail, @RequestHeader("JwtToken") String token) throws inValidUserException{
        return auth.validate(mail, token);
    }
}
