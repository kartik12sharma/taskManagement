package com.example.usermicroservice.models;

import com.example.usermicroservice.security.customGrantedAuthority;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@Entity
@JsonSerialize(as = Role.class)
@NoArgsConstructor
public class Role extends baseModel{
    private String role;
}
