package com.example.usermicroservice.DTOs;

import java.util.List;

public class setUserRolesDTO {
    private List<Long> roleIds;
}