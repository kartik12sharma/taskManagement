package com.example.usermicroservice.DTOs;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class signUpDTO {
    private String userName;
    private String email;
    private String password;
}
