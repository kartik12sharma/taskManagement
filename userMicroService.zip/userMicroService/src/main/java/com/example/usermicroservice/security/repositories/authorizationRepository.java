package com.example.usermicroservice.security.repositories;

import com.example.usermicroservice.security.models.authorization;
import com.example.usermicroservice.security.models.authorizationConsent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface authorizationRepository extends JpaRepository<authorization, String> {
    Optional<authorization> findByState(String state);
    Optional<authorization> findByAuthorizationCodeValue(String authorizationCode);
    Optional<authorization> findByAccessTokenValue(String accessToken);
    Optional<authorization> findByRefreshTokenValue(String refreshToken);
    Optional<authorization> findByOidcIdTokenValue(String idToken);
    Optional<authorization> findByUserCodeValue(String userCode);
    Optional<authorization> findByDeviceCodeValue(String deviceCode);
    @Query("select a from authorization a where a.state = :token" +
            " or a.authorizationCodeValue = :token" +
            " or a.accessTokenValue = :token" +
            " or a.refreshTokenValue = :token" +
            " or a.oidcIdTokenValue = :token" +
            " or a.userCodeValue = :token" +
            " or a.deviceCodeValue = :token"
    )
    Optional<authorization>
    findByStateOrAuthorizationCodeValueOrAccessTokenValueOrRefreshTokenValueOrOidcIdTokenValueOrUserCodeValueOrDeviceCodeValue(@Param("token") String token);
}
