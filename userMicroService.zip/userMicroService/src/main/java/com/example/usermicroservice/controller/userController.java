package com.example.usermicroservice.controller;

import com.example.usermicroservice.DTOs.setUserRolesDTO;
import com.example.usermicroservice.DTOs.userDTO;
import com.example.usermicroservice.exceptions.notFoundException;
import com.example.usermicroservice.models.user;
import com.example.usermicroservice.services.userService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class userController {
    userService userServ;
    @Autowired
    public userController(userService uS){
        userServ = uS;
    }
    @GetMapping("/{id}")
    public userDTO getUserByID(@PathVariable("id") Long id) throws notFoundException{
        userDTO user = userServ.getUserByID(id);
        return user;
    }
    @PostMapping()
    public userDTO createUser(@RequestBody() userDTO user){
        return userServ.save(user);
    }
    @PostMapping("/{id}/roles")
    public void setRoles(@PathVariable("id") Long userID, @RequestBody setUserRolesDTO request){

    }
}
