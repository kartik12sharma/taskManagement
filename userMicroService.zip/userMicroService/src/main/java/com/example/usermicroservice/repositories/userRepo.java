package com.example.usermicroservice.repositories;
import com.example.usermicroservice.DTOs.loginDTO;
import com.example.usermicroservice.models.user;
import jakarta.persistence.GenerationType;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;


@Repository
public interface userRepo extends JpaRepository<user, Long> {

    @Override
    user getReferenceById(Long aLong);

    @Override
    <S extends user> S save(S entity);

    @Override
    void deleteById(Long aLong);

//    @Query(value = "select user.* from user where email = :email", nativeQuery = true)
//    public user findByEmail(String email);

    Optional<user> findByEmail(String email);

}
