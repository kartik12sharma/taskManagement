package com.example.usermicroservice.repositories;

import com.example.usermicroservice.enums.SessionStatus;
import com.example.usermicroservice.models.session;
import com.example.usermicroservice.models.user;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface sessionRepo extends JpaRepository<session, Long> {
    @Query(value = "select s.* from session s join user u on s.user_id = u.id" +
            " where (u.email = :email and s.token = :token)", nativeQuery = true)
    public session findByEmailToken(String email, String token);

    public Optional<session> findByTokenAndUser(String token, user u);

    @Query(value = "select * from session where user_id = :id", nativeQuery = true)
    public Optional<session> findByUserEquals(Long id);

    @Modifying
    @Query(value = "update session set session_status = :status " +
            "where user_id = :id and token = :token", nativeQuery = true)
    public void deactivateSessionByUserAndToken(Long id, String token, SessionStatus status);
}
