package com.example.usermicroservice.security;

import com.example.usermicroservice.models.Role;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;

import java.io.Serializable;

@Setter
@Getter
@JsonSerialize(as = customGrantedAuthority.class)
@NoArgsConstructor
public class customGrantedAuthority implements GrantedAuthority, Serializable {
    Role role;
    public customGrantedAuthority(Role role){
        this.role = role;
    }
//    public customGrantedAuthority(){}
    @JsonIgnore
    @Override
    public String getAuthority() {
        return role.getRole();
    }
}
