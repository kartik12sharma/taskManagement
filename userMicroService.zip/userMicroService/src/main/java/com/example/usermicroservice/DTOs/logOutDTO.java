package com.example.usermicroservice.DTOs;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class logOutDTO {
    String email;
    Long userID;
    String token;
}
