package com.example.usermicroservice.security;

import com.example.usermicroservice.models.user;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.jackson.JsonMixin;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@Setter
@JsonSerialize(as = customUserDetails.class)
public class customUserDetails implements UserDetails, Serializable {
    user userRef;
    public customUserDetails(user userT){
        userRef = userT;
    }
    public customUserDetails(){}
    @Override
    @JsonIgnore
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<customGrantedAuthority> roles = new ArrayList<customGrantedAuthority>();
        userRef.getRoles().forEach(m -> {
            roles.add(new customGrantedAuthority(m));
        });
        return roles;

    }

    @Override
    @JsonIgnore
    public String getPassword() {
        return userRef.getEncryptedPassword();
    }

    @Override
    @JsonIgnore
    public String getUsername() {
        return userRef.getEmail();
    }

    @Override
    @JsonIgnore
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    @JsonIgnore
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    @JsonIgnore
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    @JsonIgnore
    public boolean isEnabled() {
        return true;
    }
}
