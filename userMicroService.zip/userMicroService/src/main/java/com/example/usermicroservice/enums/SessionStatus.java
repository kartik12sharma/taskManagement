package com.example.usermicroservice.enums;

public enum SessionStatus {
    Active,
    Dead
}
