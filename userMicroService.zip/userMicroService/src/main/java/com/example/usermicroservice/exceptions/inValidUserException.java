package com.example.usermicroservice.exceptions;

public class inValidUserException extends Exception{
    public inValidUserException(String msg){
        super(msg);
    }
}
