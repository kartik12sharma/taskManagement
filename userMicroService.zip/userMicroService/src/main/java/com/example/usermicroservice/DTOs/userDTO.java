package com.example.usermicroservice.DTOs;

import com.example.usermicroservice.models.Role;
import com.example.usermicroservice.models.user;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class userDTO {
    private String name;
    private Set<Role> roles;

    static public userDTO from(user user){
        userDTO userdto = new userDTO();
        userdto.setName(user.getName());
        return userdto;
    }
}
