package com.example.usermicroservice.services;
import com.example.usermicroservice.exceptions.notFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;
import com.example.usermicroservice.repositories.userRepo;
import com.example.usermicroservice.DTOs.userDTO;
import com.example.usermicroservice.models.user;

@Service
public class selfUserService implements userService{
    userRepo userRepo;
    @Autowired
    public selfUserService(userRepo ur){
        userRepo = ur;
    }

    @Override
    public userDTO getUserByID(Long id) throws notFoundException {
        Optional<user> uA = userRepo.findById(id);
        if(uA.isEmpty())
            throw new notFoundException("user with id "+id+" not found");
        return convertToUserDTO(uA.get());
    }

    @Override
    public userDTO deleteUserByID(Long id) throws notFoundException {
        Optional<user> uA = userRepo.findById(id);
        if(uA.isEmpty())
            throw new notFoundException("No user with specified details found");
        userRepo.deleteById(id);
        return convertToUserDTO(uA.get());
    }

    private userDTO convertToUserDTO(user userAuth) {
        userDTO us = new userDTO();
        us.setName(userAuth.getName());
        us.setRoles(userAuth.getRoles());
        return us;
    }
    @Override
    public userDTO save(userDTO object){
        user us = convertTouser(object);
        return convertToUserDTO(userRepo.save(us));
    }
    private user convertTouser(userDTO user) {
        user u = new user();
        u.setRoles(user.getRoles());
        u.setName(user.getName());
        return u;
    }
}
