package com.example.usermicroservice.services;

import com.example.usermicroservice.DTOs.logOutDTO;
import com.example.usermicroservice.DTOs.userDTO;
import com.example.usermicroservice.enums.SessionStatus;
import com.example.usermicroservice.exceptions.inValidUserException;
import com.example.usermicroservice.exceptions.notFoundException;
import com.example.usermicroservice.models.session;
import com.example.usermicroservice.models.user;
import com.example.usermicroservice.repositories.sessionRepo;
import com.example.usermicroservice.repositories.userRepo;
import io.jsonwebtoken.*;
//import io.jsonwebtoken.impl.crypto.MacSigner;
//import jakarta.transaction.Transactional;
//import org.apache.commons.codec.digest.HmacAlgorithms;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.util.MultiValueMapAdapter;
import org.springframework.security.authentication.*;

import javax.crypto.SecretKey;
import java.security.InvalidKeyException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar.*;

@Service
public class authService {
    private userRepo userDB;
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    private sessionRepo sessionrepo;
    static SecretKey keyTemp;
    @Autowired
    public authService(userRepo repo, BCryptPasswordEncoder b, sessionRepo sr){
        userDB = repo;
        bCryptPasswordEncoder = b;
        sessionrepo = sr;
    }

    public userDTO signUp(String email, String password, String name){
        user tempUser = new user();
        tempUser.setName(name);
        tempUser.setEmail(email);
        tempUser.setEncryptedPassword(bCryptPasswordEncoder.encode(password));
        userDB.save(tempUser);
        return userDTO.from(tempUser);
    }
    public ResponseEntity<userDTO> logIn(String email, String password) throws notFoundException, InvalidKeyException{
        Optional<user> reqUser1 = userDB.findByEmail(email);
        userDTO returnUser = new userDTO();

        if(reqUser1.isEmpty())
            throw new notFoundException("No entry found");

        user reqUser = reqUser1.get();

        if(!(bCryptPasswordEncoder.matches(password, reqUser.getEncryptedPassword()))){
            throw new notFoundException("Invalid credentials");
        }

        returnUser.setName(reqUser.getName());
        // generate a session for the authenticated user
        // claims map is the payload that stores the needed information in the jwt
        Map<String, Object> claims = new HashMap<String, Object>();
        claims.put("email", email);
        claims.put("createdAt", new Date());
        claims.put("expiryAt", new Date(LocalDate.now().plusDays(3).toEpochDay()));
        SecretKey key = null;
        try {
            key = KeyGenerator.getInstance("HmacSHA256").generateKey();
            System.out.println("key is " + key.toString());
            keyTemp = key;
        }
        catch(NoSuchAlgorithmException ex){
            System.out.println("Algorithm doesnt exist. "+ex.getMessage());
        }
//        String token = reqUser1.get().getName()+reqUser1.get().getEmail()+ LocalDateTime.now(); //
//        token = bCryptPasswordEncoder.encode(token);
        String token = buildJWTToken(claims, key);
        session session = new session();
        session.setSessionName("session_"+reqUser.getEmail());
        session.setUser(reqUser);
        session.setToken(token);
        session.setExpiresAt(new Date());
        session.setSessionStatus(SessionStatus.Active);
        sessionrepo.save(session);
        System.out.println("LOGIN SUCCESSFUL");
        MultiValueMap<String, String> headers = new MultiValueMapAdapter<String, String>(new HashMap<String, List<String>>());
        headers.add(HttpHeaders.SET_COOKIE, token);
        return new ResponseEntity<userDTO>(returnUser, headers, HttpStatus.OK);
    }

    public ResponseEntity<String> logOut(logOutDTO logoutdto){
        session session= sessionrepo.findByEmailToken(logoutdto.getEmail(), logoutdto.getToken());
        if(session == null) {
            System.out.println("No session found");
            return null;
        }
        session.setSessionStatus(SessionStatus.Dead);
        sessionrepo.save(session);
//        sessionrepo.deactivateSessionByUserAndToken(logoutdto.getUserID(), logoutdto.getToken(), SessionStatus.Dead);
        String body = "deactivated session for the given user.";
        ResponseEntity<String> response = new ResponseEntity<>(body, HttpStatus.ACCEPTED);
        return response;
    }
    public boolean validate(String email, String token) throws inValidUserException {
//        int startIndex = 0;
//        for(int i = 0; i < token.length(); i++){
//            if(token.charAt(i) == ' '){
//                i++;
//                startIndex = i;
//                break;
//            }
//        }
//        token = token.substring(startIndex, token.length());
        session sess = sessionrepo.findByEmailToken(email, token);/*sessionrepo.findByTokenAndUser(token, u).get();//*/
        if(sess == null)
            throw new inValidUserException("inValid user token");
        if(sess.getSessionStatus() == SessionStatus.Active ||
           sess.getExpiresAt().getTime() >= new Date(LocalDate.now().toEpochDay()).getTime())
            return true;
        session sess1 = sessionrepo.findByEmailToken(email, token);
        sess1.setSessionStatus(SessionStatus.Dead);
        sessionrepo.save(sess1);

//        Jws<Claims> claimsJws = Jwts.parser().
//                .build()
//                .parseSignedClaims(token);
//        System.out.println(claimsJws.getSignature());
        return false;
    }
    public String buildJWTToken(Map<String, Object> claims, SecretKey key) throws InvalidKeyException {
        JwtBuilder builder = Jwts.builder();
        builder.addClaims(claims);
        builder.signWith(key, SignatureAlgorithm.HS256);
        String token = builder.compact();
        return token;
    }
}
/*
* when spring security is added, then
* it by default disables post requests. Hence, we need to add csrf and cors properties.
* */